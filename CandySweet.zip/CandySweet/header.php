<?php
session_start();
$current_page = basename($_SERVER['PHP_SELF']); // Get the current page name



if(isset($_SESSION['username'])){
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Candy Store</title>
<link rel="stylesheet" type="text/css" href="files/style.css">
	<script src="script.js"></script>
<style>
#intro{ padding:0px 128px;}
nav {
    position: relative; /* Set position to relative */
}


section.pbanner {
    position: relative; /* Set position to relative */
    z-index: 0; /* Set a lower z-index value */
}
/* Dropdown CSS */
nav ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
}

nav ul li {
    position: relative;
    display: inline-block;
}


nav ul li a {
    text-decoration: none;
    padding: 10px;
    display: block;
}

nav ul li ul {
    display: none;
    position: absolute;
    top: 100%;
    left: 0;
    background-color: white;
    padding: 0;
    margin: 0;
    list-style-type: none;
    z-index: 1; /* Set z-index to a higher value */
}

nav ul li:hover ul {
    display: block;
}

nav ul li ul li {
    width: 200px;
    display: block;
}

nav ul li ul li a {
    padding: 10px;
    white-space: nowrap;
}

.active {
    font-weight: bold;
    color: red;
}
</style>
</head>
<body>

<img id="coverimg"  usemap="#covermap" src="files/cover.jpg" width="100%" height="350" />

<header>
</header>

<section>
  <nav>
    <ul>
     <li>
	 <a class="<?php echo ($current_page == 'index.php') ? 'active' : ''; ?>" href="index.php"> Home</a>
	 </li>
	 <li><a class="<?php echo ($current_page == 'blog.php') ? 'active' : ''; ?>" href="blog.php">Blog </a></li>
      <li>
        <a href="#">Products</a>
        <ul>
          <li><a class="<?php echo ($current_page == 'SaltWaterTaffy.php') ? 'active' : ''; ?>" href="SaltWaterTaffy.php">Salt Water Taffy</a></li>
          <li><a class="<?php echo ($current_page == 'Bears.php') ? 'active' : ''; ?>" href="Bears.php">Bears</a></li>
          <li><a class="<?php echo ($current_page == 'FruitSours.php') ? 'active' : ''; ?>" href="FruitSours.php">Fruit Sours</a></li>
          <li><a class="<?php echo ($current_page == 'ChocolateSticks.php') ? 'active' : ''; ?>" href="ChocolateSticks.php">Chocolate Sticks</a></li>
        </ul>
      </li>
	 <li><a class="<?php echo ($current_page == 'PopularGifts.php') ? 'active' : ''; ?>" href="PopularGifts.php">Popular Gifts </a></li>
	 <li><a class="<?php echo ($current_page == 'offers.php') ? 'active' : ''; ?>" href="offers.php">Offers </a></li>
	 <li><a class="<?php echo ($current_page == 'aboutus.php') ? 'active' : ''; ?>" href="aboutus.php">About us </a></li>
	 <li><a class="<?php echo ($current_page == 'contactus.php') ? 'active' : ''; ?>" href="contactus.php">Contact us </a></li>
	 <li><a class="<?php echo ($current_page == 'logout.php') ? 'active' : ''; ?>" href="logout.php">Logout </a></li>
    </ul>
  </nav>
<?php } else {
    header("Location: signin.php");
    exit();
?>
<?php } ?>
