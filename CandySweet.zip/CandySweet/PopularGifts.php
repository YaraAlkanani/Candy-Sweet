<?php include 'header.php'; ?>

  <article >
	
  	<div class="infoList" >
	<section class="pbanner pimg2" style="margin: 10px 0px;">
		
		<h1>Gifts</h1>
	</section>
	<ul class="plist">
		<li>
			<img src="images/Gifts/g1.jpg" width="250" height="200" alt="Dell Inspiron 14">
			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>Happy Birthday Chocolate Covered Pretzels</strong> </a>
				<p style="text-align:left; "> 
				12 Assorted Gourmet Chocolate Pretzels in a Happy Birthday Chocolate Gift Box - Mouthwatering Birthday Treats For Women & Men
                    <br>
					<br>
					<center> 10 SAR </center> 
				</p>
			</div>
		</li>
		<li>
			<img src="images/Gifts/g2.jpg" width="250" height="200" alt="Dell Inspiron 5378">
			<div class="inline" style="width: 500px;" ">
			<a href="#"><strong>Mrs. Fields - 30 Nibblers Signature Cookie Tin </strong> </a>
				<p style="text-align:left; "> 
				
					it assorted with 30 Nibblers Bite-Sized Cookies in our 5 Signature Cookie Flavors (30 Count)<br>
					<br>
					<center> 15 SAR</center> 
				</p>
			</div>
		</li>			
		<li>
			<img src="images/Gifts/g3.jpg" width="250" height="200" alt="Dell Inspiron 14 5406">

			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>Chocolate Gift Basket</strong> </a>
				<p style="text-align:left; "> 
				 Candy Food Gifts Arrangement Platter, Gourmet Snack Box, Birthday Present Idea, Corporate Him & Her, Men Women Sympathy Family Parties & Get Well- Bonnie & Pop<br>
					<br>
					<center> 16 SAR </center>
				</p>
			</div>
		</li>	
		<li>
			<img src="images/Gifts/g4.jpg" width="250" height="200" alt="Dell Inspiron 13">
			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>Mothers Day Gifts for Mom</strong> </a>
				<p style="text-align:left; "> 
				Popcorn Gift Set, 10 Piece Set, 5 Gourmet Popcorn Kernels, 5 Popcorn Seasoning Flavoring, Non-GMO Movie Night Basket Gift Set, Gifts For Women, Daughter, Grandma<br>
					<center> 7 SAR</center>
				</p>
			</div>
		</li>
	</ul>
	</div>

	
   </article>
   
   
<?php include 'footer.php'; ?>