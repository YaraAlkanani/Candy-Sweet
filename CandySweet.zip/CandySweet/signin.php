<!DOCTYPE html>
<html lang="en">
<?php
session_start();
#if(isset($_SESSION['username'])){
#	header("location:index.php");
#	exit();
#}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if(isset($_POST['signin_submit'])){
		$_SESSION['username']=$_POST['email'];
		header("Location:index.php");
        exit();
	}
}
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Sign In</h2>
        </form>
		
        <form id="signin-form2" method="post">
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" name="signin_submit">Sign In</button>
        </form>
		<p>Forgot your password? <a href="forgetpassword.php">Click here</a></p>
		<p>Don't have an account? <a href="signup.php">Sign up</a></p>

    </div>

    <script src="script.js"></script>
</body>
</html>
