<?php include 'header.php'; ?>

  <article >
	
  	<div class="infoList" >
	<section class="pbanner pimg3" style="margin: 10px 0px;">
		
		<h1>Sours</h1>
	</section>
	<ul class="plist">
		<li>
			<img src="images/FruitSours/sours1.jpg" width="250" height="200" alt="Dell Inspiron 14">
			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>SHi-Chew Chewy Fruit Candies</strong> </a>
				<p style="text-align:left; "> 
				SWEET & SOUR Mix Flavors Stand-Up Bag 12.7 Oz. with Adorable Storage Bag Clip (Sweet & Sour Mix (Watermelon, Lemon, Grapefruit))
                    <br>
					<br>
					<center> 5 SAR </center> 
				</p>
			</div>
		</li>
		<li>
			<img src="images/FruitSours/sours2.jpg" width="250" height="200" alt="Dell Inspiron 5378">
			<div class="inline" style="width: 500px;" ">
			<a href="#"><strong>SweeTARTS Chewy Fusions Candy, </strong> </a>
				<p style="text-align:left; "> 
				
					SweeTARTS Chewy Fusions Candy, Fruit Punch Medley, Springtime Easter Candy, 9 Ounce<br>
					<br>
					<center> 8 SAR</center> 
				</p>
			</div>
		</li>			
		<li>
			<img src="images/FruitSours/sours3.jpg" width="250" height="200" alt="Dell Inspiron 14 5406">

			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>Sour & Sweet Peach Rings</strong> </a>
				<p style="text-align:left; "> 
				 These gummy rings are a tribute to the luscious taste of ripe, juicy peaches and the tantalizing fusion of sour and sweet notes<br>
					<br>
					<center> 8 SAR </center>
				</p>
			</div>
		</li>	
		<li>
			<img src="images/FruitSours/sours4.jpg" width="250" height="200" alt="Dell Inspiron 13">
			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>Emporium Candy Assorted Fruit Sours</strong> </a>
				<p style="text-align:left; "> 
				Fruit Sours Chewy Candy Balls - 2 lbs of Tart Fresh Delicious Cherry Orange Apple Lemon Grape Candy, 2 Pound (Pack of 1)
				<br>
					<center> 10 SAR</center>
				</p>
			</div>
		</li>
	</ul>
	</div>

	
   </article>
   
   
<?php include 'footer.php'; ?>