<?php include 'header.php'; ?>

  <article>
<section class="recent">
    <div class="container">
        <h1>Recent Blogs</h1>
        <div class="newsList">
            <ul>
                <?php 
                // Define an array with hardcoded article information
                $articles = array(
                    array(
                        'news_id' => 1,
                        'image_name' => 'blog1.PNG',
                        'title' => 'Thanksgiving',
                        'date' => 'May 12, 2024',
                        'description' => 'Thanksgiving Decorating Ideas with Candy.'
                    ),
                    array(
                        'news_id' => 2,
                        'image_name' => 'blog2.PNG',
                        'title' => 'Sours',
                        'date' => 'May 4, 2024',
                        'description' => 'How to Make Gingerbread Houses'
                    ),
					array(
                        'news_id' => 3,
                        'image_name' => 'blog3.PNG',
                        'title' => 'Holidays & Special Events',
                        'date' => 'May 2, 2024',
                        'description' => 'Chocolate Cinnamon Bear Candy is Unique to its Home State'
                    ),
                    // Add more articles here as needed
                );

                // Loop through each hardcoded article and display it
                foreach ($articles as $article) {
                ?>
                <li>
                    <a href="displayNewsArticle.php?newsid=<?php echo $article['news_id'] ?>">
                        <img src="images_blogs/<?php echo $article['image_name'] ?>" width="320" height="260">
                    </a>
                    <div class="inline">
                        <a href="displayBlog.php?newsid=<?php echo $article['news_id'] ?>">
                            <strong><?php echo $article['title'] ?></strong>
                        </a>
                        <h5><?php echo $article['date'] ?></h5>
                        <p style="font-size:17px;"><?php echo $article['description'] ?></p>
                        <br/>
                        <a href="displayBlog.php?newsid=<?php echo $article['news_id'] ?>" class="thm-btn" style="font-size:15px;">Read More</a>
                    </div>
                </li>
                <?php 
                } // End of foreach loop
                ?>
            </ul>
        </div>
    </div>
</section>

	
   </article>
   
<?php include 'footer.php'; ?>