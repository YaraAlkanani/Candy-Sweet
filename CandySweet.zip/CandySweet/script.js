function validate() {
    // Fetching input values
    var name = document.getElementById("name").value.trim();
    var email = document.getElementById("email").value.trim();
    var feedback = document.getElementById("Feedback").value.trim();
    var checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');

    // Name validation
    if (name.length < 4) {
        alert("Name must be at least 4 characters long.");
        return false;
    }

    // Email validation using a regular expression
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        alert("Please enter a valid email address.");
        return false;
    }

    // Feedback length validation
    if (feedback.length < 11) {
        alert("Feedback must be at least 10 characters long.");
        return false;
    }

    // Checkbox validation
    if (checkboxes.length === 0) {
        alert("Please select at least one checkbox.");
        return false;
    }

    // If all validations pass, return true
    return true;
}

// Sign In Form Submission
document.getElementById("signin-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the default form submission

    // Get the values from the form
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    // Here you can add your validation logic
    // For example, check if the email and password meet certain criteria

    // Once validated, you can submit the form using AJAX or any other method
    // For demonstration purposes, let's just log the values to the console
    console.log("Email:", email);
    console.log("Password:", password);
});

// Sign Up Form Submission
document.getElementById("signup-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the default form submission

    // Get the values from the form
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    // Here you can add your validation logic
    // For example, check if the email, password, and name meet certain criteria

    // Once validated, you can submit the form using AJAX or any other method
    // For demonstration purposes, let's just log the values to the console
    console.log("Name:", name);
    console.log("Email:", email);
    console.log("Password:", password);
});

// Forget Password Form Submission
document.getElementById("forget-password-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the default form submission

    // Get the email from the form
    var email = document.getElementById("email").value;

    // Here you can add your validation logic
    // For example, check if the email is valid

    // Once validated, you can submit the form using AJAX or any other method
    // For demonstration purposes, let's just log the email to the console
    console.log("Email:", email);
});

// Reset Password Form Submission
document.getElementById("reset-password-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the default form submission

    // Get the values from the form
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirm-password").value;

    // Here you can add your validation logic
    // For example, check if the password and confirm password match

    // Once validated, you can submit the form using AJAX or any other method
    // For demonstration purposes, let's just log the values to the console
    console.log("Password:", password);
    console.log("Confirm Password:", confirmPassword);
});
