<?php include 'header.php'; ?>

  <article style="background-color:#41b6d7; color:black; text-align:left; padding-top:0px;">
	<form name = "myForm" >
	 <label> Name: <label> <input type="text" id="name" name="Name" size="33" />
	 <br/>
	  <br/>
	 <label> Email: <label> <input type="text" id="email" name="Email" size="33" />
	 <br/>
	  <br/>
	 <label> your feedback about our website: <label> <br/>
	 <textarea type="text" name="Feedback" id="Feedback" rows="10" cols="40"> </textarea>
	  <br/>
	   <br/>
	 <label> Which types of laptop are you interested in: <label>
	  <br/>
		<input type="checkbox"   value="Salt Water Taffy"/> Salt Water Taffy  <br />
		<input type="checkbox"   value="Bears"/> Bears<br />
		<input type="checkbox"  value="Fruit Sours"/>  Fruit Sours <br />
		<input type="checkbox"  value="Chocolate Sticks"/> Chocolate Sticks <br />
		<input type="checkbox"  value="Gifts"/> Gifts <br />
	  <br/>
	   <br/>
		<input  class="thm-btn"  type="submit" onclick="validate()" value="Submit" name="submit"/>
	</form>
	
   </article>
<?php include 'footer.php'; ?>