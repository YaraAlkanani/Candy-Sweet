<?php include 'header.php'; ?>
<style>

#article-container{

	 padding:20px;
     margin:0% 9%;
 
}

</style>

<?php
// Define hardcoded array with article information
$articles = array(
    1 => array(
        'image_name' => 'blog1.PNG',
        'title' => 'Thanksgiving',
        'description' => 'Thanksgiving Decorating Ideas with Candy.',
        'date' => 'May 12, 2024',
        'base_paragraph' => 'Every year, on Thanksgiving, we gather with our friends and family to feast and give thanks. Whether you are a guest or the host, Thanksgiving is the perfect time to express gratitude and appreciation for those you love with an unexpected cheerful treat or thoughtful craft.
                     		This year, forget the traditional pumpkin trimmings; delight your guests or host with aesthetic candy décor. The warm, festive colors and delectable flavors of fall will put a smile on your guests faces - young and old!
							We hope you enjoy our fun collection of Thanksgiving craft projects that are ideal for family time, craft night and school or church activities. Thanksgiving officially marks the beginning of the "Season of Giving" and is the perfect time of the year to get together with those you care about. 
							Using candy to craft something special for your feast is easy, fun and affordable. 
							Our creative candy décor includes an edible welcoming wreath and elegant, mouthwatering centerpiece ideas that will delight everyone.',
        'subtitle1' => 'Welcoming Fall Taffy Wreath',
        'paragraph1' => 'A salt-water taffy wreath is a whimsical way to welcome Thanksgiving guests or to present a sweet and unique hostess gift. This is a fun, unique and inexpensive group craft for ages 12 and up; *supervision may be required for hot glue gun use.
						Sweetcandy"s World Famous Salt Water Taffy(available in bulk) comes in an amazing array of tempting fall flavors like s"mores, caramel, chocolate hazelnut, coconut and honey (pictured). Express your sweet side with this festive fall taffy wreath:',
        'subtitle2' => 'What You"ll Need, per Wreath:',
        'paragraph2' => '- About 60 pieces of Salt Water Taffy
						- Wire Hanger
						- Tensile Stems
						- Large Fall-Colored Ribbon for the Bow
						- Wire Cutters / Pliers / Scissors'
    ),
    2 => array(
        'image_name' => 'blog2.PNG',
        'title' => 'Sours',
        'description' => 'How to Make Gingerbread Houses',
        'date' => 'May 4, 2024',
        'base_paragraph' => "Sweet's Candy Company is proud to present: How to Make Gingerbread Houses with detailed instructions for our Aromatic Gingerbread recipe, the Perfect Royal Icing recipe, gingerbread house assembly.
		instructions, decorating ideas and hacks and our free downloadable gingerbread house template all in one place, so you can spend more time with friends and family – making memories this holiday season.
		",
        'subtitle1' => 'A Time-Honored Tradition',
        'paragraph1' => "A gingerbread house was first mentioned in the literature of Grimm's fairy tale Hansel, and Gretel published in 1812
		This time-honored tradition of adding decorated gingersnap cookies to decorate Christmas trees in
		colonial North America was adapted from the German tradition of making gingerbread houses. 
		The tradition became associated with celebrating the Christmas season that many families in the US have cherished for the past 200 years. 
		Make sure to give yourself several days or a full weekend for shopping and gathering supplies, baking, crafting decorations, construction, and final decorations.",
        'subtitle2' => 'Plan, Organize and Bake!',
        'paragraph2' => "We recommend you devote two days to gather ingredients and supplies, bake your structure and make the
		royal icing in preparation for day three so you can devote special attention to detail in decorating and
		constructing the house and avoid feeling overwhelmed. Here is a 3-4 day time timeline to ensure everything
		goes smooth and you don't get your tinsel in a tangle:"
    ),
	3 => array(
        'image_name' => 'blog3.PNG',
        'title' => 'Holidays & Special Events',
        'description' => 'Chocolate Cinnamon Bear Candy is Unique to its Home State',
        'date' => 'May 2, 2024',
        'base_paragraph' => "Chocolate covered cinnamon bears are to Utah like the Goo Goo Cluster is to Tennessee or the Idaho Spud is to Idaho.
		All of these crave-able confections marry delectable ingredients with a luxurious chocolate coating.
		For those who don't already know, Utahns love candy, in fact, we eat more candy per capita than any other US
		state! So, it’s no surprise that, for almost 120 years, the Sweet's Candy Company in Salt Lake City, is renowned
		as one of the oldest family-owned and operated candy producing companies in the country.  
		The Sweet Candy Company discovered the unusual cinnamon chocolate combination back in 1994 and caught
		candy lovers by surprise with the new spicy, sweet combination. Sweet's Candy Company president, Richard
		Kay admits that while demand is high, supply is limited; even though Sweet's Candy now produces nearly one
		million pounds of chocolate cinnamon bears for distribution around the globe each year.  
		",
        'subtitle1' => 'Chocolate Cinnamon Bear Candy is Unique to its Home State',
        'paragraph1' => "The chocolate cinnamon bear joins the ranks of Utah's unusual favorites like fry sauce, a wide array of Jello
		concoctions, funeral potatoes, and heavenly scones. While not everyone is a fan of all of Utah's favorites, one
		thing is certain, if you are a sweet-heat lover, you're going to love Sweet's chocolate covered cinnamon
		bears. Sweet's Candy Company hold the hearts of all Utahns by producing amazing candy, made with only 
		the best ingredients and by using old-world manufacturing methods",
        'subtitle2' => 'How Are Chocolate Cinnamon Bears Made?',
        'paragraph2' => "The magic happens at the Sweet's Candy factory located in SLC, Utah. There are designated rooms for each of
		the different candy making processes like the fruit sours room, the taffy room, Non-GMO, and the chocolate
		enrobing room where spicy little red bears get their chocolate covering.
		
		- First cinnamon bears ride along a massive conveyor belt, as long as a football field.
		- The conveyor belt takes the little guys for a ride under a chocolate waterfall.
		- They continue their journey on the conveyor to be cooled to just the right temperature.
		- Lastly, these crave-able little bears are bagged for distribution to grocery stores, retailers and through
		the Sweet's website for delivery directly to your front door.  "
    ),
    // Add more articles here as needed
);

// Check if newsid is provided in $_GET
if(!empty($_GET['newsid'])) {
    $id = $_GET['newsid'];
    // Check if the provided newsid exists in the articles array
    if(isset($articles[$id])) {
        $article = $articles[$id]; // Retrieve the article content
?>
<div id="article-container">
    <img class="coverimage" src="images_blogs/<?php echo $article['image_name']; ?>" width="320" height="260">
    <h1><?php echo $article['title']; ?></h1>
    <br/>
    <p style="font-size:15px;"><?php echo $article['description']; ?></p>
    <br/>
    <p><strong>Published </strong><strong style="color:#0000fa"><?php echo $article['date']; ?></strong></p>
    <br/>
    <br/>
    <p><?php echo nl2br($article['base_paragraph']); ?></p>
    <h2 style="color:#0000fa;"><?php echo $article['subtitle1']; ?></h2>
    <p><?php echo nl2br($article['paragraph1']); ?></p>
    <br/>
    <h2 style="color:#0000fa;"><?php echo $article['subtitle2']; ?></h2>
    <p><?php echo nl2br($article['paragraph2']); ?></p>
    <br/>
</div>
<?php
    } else {
        echo "<p>Article not found!</p>";
    }
} else {
    echo "<p>No blog id provided!</p>";
}
?>

	

   
<?php include 'footer.php'; ?>