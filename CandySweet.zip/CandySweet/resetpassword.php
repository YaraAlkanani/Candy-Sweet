<!DOCTYPE html>
<html lang="en">
<?php
$notification="";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if(isset($_POST["reset"]))  {
		$password = $_POST['password'];
		$confirmPassword = $_POST['confirm-password'];
		
		if ($password == $confirmPassword) {
			header("Location: signin.php");
			exit();
		} else {
			$notification= "Passwords do not match. Please try again.";
		}
	}
}
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Reset Password</h2>
        <form id="reset-password-form" method="POST">
            <div class="form-group">
                <label for="password">New Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="confirm-password">Confirm New Password:</label>
                <input type="password" id="confirm-password" name="confirm-password" required>
            </div>
            <button type="submit" name="reset">Reset Password</button>
        </form>
		<?php echo $notification; ?>
    </div>

    <script src="script.js"></script>
</body>
</html>
