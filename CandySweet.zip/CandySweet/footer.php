</section>


<footer>

      <p> &#169;  2022 Copyright:
        <a  style="color:#000;" href="#"> 
		Candy Sweet</a>
      </p>

</footer>

</body>
</html>