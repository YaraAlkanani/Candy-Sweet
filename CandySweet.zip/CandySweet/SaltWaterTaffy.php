<?php include 'header.php'; ?>

  <article >
	
  	<div class="infoList" >
	<section class="pbanner pimg1" style="margin: 10px 0px;">
		
		<h1>Salt Water Taffy</h1>
	</section>
	<ul class="plist">
		<li>
			<img src="images/SWT/swt1_.jpg" width="250" height="200" alt="Dell Inspiron 14">
			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>Taffy Town</strong> </a>
				<p style="text-align:left; "> 
				15 Flavors of Saltwater Taffies in Gift Ready Reusable Square Grip Jar (15 Flavor Mix, Large)
                    <br>
					<br>
					<center> 6 SAR </center> 
				</p>
			</div>
		</li>
		<li>
			<img src="images/SWT/swt2.jpg" width="250" height="200" alt="Dell Inspiron 5378">
			<div class="inline" style="width: 500px;" ">
			<a href="#"><strong>Sweet Candy Original Assortment </strong> </a>
				<p style="text-align:left; "> 
					Delicious Chewy Candy - Individually Wrapped - Classic Nostalgic Candies- 3LB - Approximately 210 Pieces
					<br>
					<br>
					<center> 9 SAR</center> 
				</p>
			</div>
		</li>			
		<li>
			<img src="images/SWT/swt3.jpg" width="250" height="200" alt="Dell Inspiron 14 5406">

			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>Gourmet Assorted Taffy</strong> </a>
				<p style="text-align:left; "> 
				 Saltwater Taffy, Gourmet Assorted Taffy, 24 Ounces
				  <br>
					<br>
					<center> 7 SAR </center>
				</p>
			</div>
		</li>	
		<li>
			<img src="images/SWT/swt4.jpg" width="250" height="200" alt="Dell Inspiron 13">
			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>San Francisco Salt Water Taffy</strong> </a>
				<p style="text-align:left; "> 
				Small Batch Salt Water Taffies Made in the USA - Super Soft, Sweet, Taffy Candy - Guaranteed Fresh - Gluten-Free, Soy-Free.
				    <br>
					<br>
					<center> 8 SAR</center>
				</p>
			</div>
		</li>
	</ul>
	</div>

	
   </article>
   
   
<?php include 'footer.php'; ?>