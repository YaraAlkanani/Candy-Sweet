<?php include 'header.php'; ?>

  <article >
	
  	<div class="infoList" >
	<section class="pbanner pimg2" style="margin: 10px 0px;">
		
		<h1>Cinnamon Bears</h1>
	</section>
	<ul class="plist">
		<li>
			<img src="images/Bear/bear1.jpg" width="250" height="200" alt="Dell Inspiron 14">
			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>Sweets Cinnamon Bears Candy</strong> </a>
				<p style="text-align:left; "> 
				Classic bear shape, strong cinnamon taste!, Gluten free, fat free,Kosher Parve ,Made in the USA!
                    <br>
					<br>
					<center> 6 SAR </center> 
				</p>
			</div>
		</li>
		<li>
			<img src="images/Bear/bear2.jpg" width="250" height="200" alt="Dell Inspiron 5378">
			<div class="inline" style="width: 500px;" ">
			<a href="#"><strong>Jelly Belly Confections </strong> </a>
				<p style="text-align:left; "> 
				
					Ingredients: SUGAR, CORN SYRUP, POTATO STARCH, CONTAINS 2% OR LESS OF THE FOLLOWING: ARTIFICIAL FLAVOR, YELLOW 5, RED 40
					<br>
					<br>
					<center> 3 SAR</center> 
				</p>
			</div>
		</li>			
		<li>
			<img src="images/Bear/bear3.jpg" width="250" height="200" alt="Dell Inspiron 14 5406">

			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>Sweets Cinnamon Santas</strong> </a>
				<p style="text-align:left; "> 
				 Sweets Cinnamon Santas 14oz, Pack of 2. Christmas Cinnamon Candy, Cinnamon Bears, Cinnamon Gummy Bears Candy, Sweets Cinnamon Bears Candy
				  <br>
					<br>
					<center> 8 SAR </center>
				</p>
			</div>
		</li>	
		<li>
			<img src="images/Bear/bear4.jpg" width="250" height="200" alt="Dell Inspiron 13">
			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>Cinnamon Organic Bears</strong> </a>
				<p style="text-align:left; "> 
				CINNAMON ORGANIC BEARS - Packed with the perfect amount of cinnamon flavor, you'll love these delicious bite sized bears! <br>
					<br>
					<center> 8 SAR</center>
				</p>
			</div>
		</li>
	</ul>
	</div>

	
   </article>
   
   
<?php include 'footer.php'; ?>