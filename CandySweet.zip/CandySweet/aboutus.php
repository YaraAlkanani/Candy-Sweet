<?php include 'header.php'; ?>
<style> 
.shadowbox {
  border: 1px solid;
  padding: 10px;
  box-shadow: 5px 10px black;
}
</style>
  <article style="background-color:#41b6d7; color:white; text-align:left; padding-top:0px;">
  <br>
  <br>
	<h2>Contact Information</h2>
	<ul class="black">
		<li><strong>Location: </strong> King Fahd Road, Al-Mushrifah District, Mushrifah, Jeddah 23336, Saudi Arabia</li>
		<li><strong>Country: </strong> Saudi Arabia</li>
		<li><strong>City: </strong> Al Hayatt Continental</li>
		<li><strong>Phone number: </strong> 056 570 3082</li>
		<li><strong>International phone number: </strong> +966 56 570 3082</li>
		<li><strong>Latitude and longitude: </strong> 21.5383152,39.19223119999999</li>
	</ul>
	<h2>Frequently Asked Questions</h2>
	<ol class="black">
		<li><strong>What types of candy do you offer?</strong>
			<p>We offer a wide variety of candies including Salt Water Taffy, Bears, Fruit Sours, and Chocolate Sticks. Our selection is always expanding to include new and exciting treats!</p>
		</li>
		<li><strong>Do you offer sugar-free or gluten-free options?</strong>
			<p>Yes, we have a range of sugar-free and gluten-free candies. You can find these options by using the filters on our website or checking the product descriptions.</p>
		</li>
		<li><strong>How can I place an order?</strong>
			<p>To place an order, simply browse our selection, add your favorite candies to the cart, and proceed to checkout. You can create an account for faster checkout in the future, or checkout as a guest.</p>
		</li>
		<li><strong>What is your return policy?</strong>
			<p>We want you to be happy with your purchase. If you are not satisfied with your order, please contact our customer service within 14 days of receiving your order. We will assist you with the return process and provide a refund or replacement as needed.</p>
		</li>
</ol>
<h2>Social Media external Links:</h2>
		<a href="https://www.instagram.com/" target="_blank">Follow us on Instagram</a>
		<br>
		<a href="https://www.facebook.com/" target="_blank">Follow us on Facebook</a>
	<br> <br>
	<h2>Working Hours </h2>  
	<table>
	<tr>
	<th> Day </th>
	<td> From </td>
	<td> To </td>
	</tr>
	
	<tr>
	<th> Saturday </th>
	<td>  9:00 am </td>
	<td> 10:00 pm </td>
	</tr>
	<tr>
	<th> Sunday </th>
	<td> 9:00 am </td>
	<td> 10:00 pm </td>
	</tr>
	<tr>
	<th> Monday </th>
	<td>  9:00 am </td>
	<td> 11:00 pm </td>
	</tr>
	<tr>
	<th> Tuesday </th>
	<td> 10:00 am </td>
	<td> 11:00 pm </td>
	</tr>
	<tr>
	<th> Wednesday </th>
	<td> 9:00 am </td>
	<td> 12:00 pm </td>
	</tr>
	<tr>
	<th> Thursday </th>
	<td> 9:00 am </td>
	<td> 10:00 pm </td>
	</tr>
	<tr>
	<th> Friday </th>
	<td colspan="2"> Closed </td>

	</tr>
	</table>
	<br> <br>
	<h2>Our Brands</h2>  
	
      <div class="shadowbox" style = "background-image: url('files/g2.jpg'); 
         width:400px; 
         height:200px; 
         position:relative; 
         top:120px; 
         left:200px; 
         z-index:2">
      </div>
      
      <div class="shadowbox" style = "background-image: url('files/g1.jpg');
         width:400px; 
         height:200px; 
         position:relative; 
         top:-200px; 
         left:35px; 
         z-index:1;">
      </div>
      
      <div class="shadowbox" style = "background-image: url('files/g3.jpg');
         width:400px; 
         height:250px; 
         position:relative; 
         top:-170px; 
         left:400px; 
         z-index:3;">
      </div>
      <div class="shadowbox" style = "background-image: url('files/g4.jpg');
         width:400px; 
         height:300px; 
         position:relative; 
         top:-250px; 
         left:600px; 
         z-index:4;">
      </div>


   </article>
<?php include 'footer.php'; ?>