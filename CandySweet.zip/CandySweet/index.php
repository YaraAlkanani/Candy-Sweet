<?php include 'header.php'; ?>

  <article>
    <h1 style="text-align: center; font-size:40px;">Welcome To Candy Sweet Website</h1>
	<p id="intro" >Welcome to Candy Sweet, your one-stop shop for all your candy cravings! Whether you're a fan of Salt Water Taffy, Bears, Fruit Sours, Chocolate Sticks, or looking for the perfect gift for a sweet-toothed friend, we've got you covered.
	</p>
	<p id="intro" >
	But that's not all - our website also offers a deliciously entertaining blog filled with candy-inspired content to satisfy your cravings for all things sweet. So sit back, relax, and indulge in the mouthwatering world of Candy Sweet. Happy browsing!
	</p>

	<br>
	
   </article>
   
<?php include 'footer.php'; ?>