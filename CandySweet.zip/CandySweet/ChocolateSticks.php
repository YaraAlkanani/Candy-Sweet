<?php include 'header.php'; ?>

  <article >
	
  	<div class="infoList" >
	<section class="pbanner pimg2" style="margin: 10px 0px;">
		
		<h1>Chocolate Sticks</h1>
	</section>
	<ul class="plist">
		<li>
			<img src="images/ChocolateSticks/cs1.jpg" width="250" height="200" alt="Dell Inspiron 14">
			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>Sweet Candy Milk Chocolate Orange Sticks	</strong> </a>
				<p style="text-align:left; "> 
				Chocolate Covered Candy - Orange Flavor With Rich Chocolate Coating - Old Fashioned Sweet Treat - One (1) 10.5oz Box
                    <br>
					<br>
					<center> 7 SAR </center> 
				</p>
			</div>
		</li>
		<li>
			<img src="images/ChocolateSticks/cs2.jpg" width="250" height="200" alt="Dell Inspiron 5378">
			<div class="inline" style="width: 500px;" ">
			<a href="#"><strong>Sweets Raspberry Milk Chocolate Sticks </strong> </a>
				<p style="text-align:left; "> 
				
					 Chocolate Candy, Chocolate Box, Chocolate Covered Fruit, Box of Chocolates, Chocolate Raspberry Candy, Fruit Sticks,<br>
					<br>
					<center> 7 SAR</center> 
				</p>
			</div>
		</li>			
		<li>
			<img src="images/ChocolateSticks/cs3.jpg" width="250" height="200" alt="Dell Inspiron 14 5406">

			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>Pirouline Rolled Wafers</strong> </a>
				<p style="text-align:left; "> 
				  Chocolate Hazelnut – Rolled Wafer Sticks, Crème Filled Wafers, Rolled Cookies for Coffee, Tea, Ice Cream, Snacks, Parties, Gifts, and More – 3.25oz Tin 2pk<br>
					<br>
					<center> 4 SAR </center>
				</p>
			</div>
		</li>	
		<li>
			<img src="images/ChocolateSticks/cs4.jpg" width="250" height="200" alt="Dell Inspiron 13">
			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>Baklava Chocolate Sticks</strong> </a>
				<p style="text-align:left; "> 
				 Hazelnut Chocolate Bar Cream Crispy Douch - Chocolate Gifts - Box of Chocolate Gift - Sticks with Chocolate - Crispy Phyllo Dough - MADE IN USA<br>
					<center> 4 SAR</center>
				</p>
			</div>
		</li>
	</ul>
	</div>

	
   </article>
   
   
<?php include 'footer.php'; ?>