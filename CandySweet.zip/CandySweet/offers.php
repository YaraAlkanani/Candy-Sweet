<?php include 'header.php'; ?>

  <article >
	
  	<div class="infoList" >
	<section class="pbanner pimg3" style="margin: 10px 0px;">
		
		<h1>10 % Offers</h1>
	</section>
	<ul class="plist">
		<li>
			<img src="images/offers/f1.jpg" width="250" height="200" alt="Dell Inspiron 14">
			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>KREMERY Creamy Chocolate Cravings</strong> </a>
				<p style="text-align:left; "> 
				 Fathers Day Chocolate Covered Oreo Sandwich Cookies Gift Basket, Assorted Candy Toppings (12 Count) Teacher Appreciation Gifts Birthday Care Package
                    <br>
					<br>
					<center>Old price 10 SAR </center> 
					<center>New Price 9 SAR </center>
				</p>
			</div>
		</li>
		<li>
			<img src="images/offers/f2.jpg" width="250" height="200" alt="Dell Inspiron 5378">
			<div class="inline" style="width: 500px;" ">
			<a href="#"><strong>A Gift Inside Chocolate</strong> </a>
				<p style="text-align:left; "> 
				
					Give the gift of best-selling deliciousness or treat yourself to two of our prized house-made gooey caramel corns: butter and dark-chocolate drizzled, Ghirardelli dark chocolate and caramel-filled squares with along with 2 flavors of crunchy confection mini pretzels<br>
					<br>
					<center>Old price 20 SAR </center> 
					<center>New Price 18 SAR </center>
				</p>
			</div>
		</li>			
	</ul>
	</div>
  	<div class="infoList" >
	<section class="pbanner pimg5" style="margin: 10px 0px;">
		
		<h1>20 % Offers</h1>
	</section>
	<ul class="plist">
		<li>
			<img src="images/offers/f3.jpg" width="250" height="200" alt="Dell Inspiron 14">
			<div class="inline" style="width: 500px;" >
			<a href="#"><strong>Zalatimo Sweets Since 1860</strong> </a>
				<p style="text-align:left; "> 
				 100% All Natural Sesame & Butter Shortbread Cookies, Square Metal Gift Tin, Slightly Sweet Cookies with No Preservatives, No Additives, No Corn Starch, No Syrups! 1.4Lbs <br>
					<br>
					<center>Old price 20 SAR </center> 
					<center>New Price 16 SAR </center>
				</p>
			</div>
		</li>
		<li>
			<img src="images/offers/f4.jpg" width="250" height="200" alt="Dell Inspiron 5378">
			<div class="inline" style="width: 500px;" ">
			<a href="#"><strong>Ferrero Collection</strong> </a>
				<p style="text-align:left; "> 
				
					16 Count, Premium Gourmet Assorted Hazelnut Milk Chocolate, Dark Chocolate and Coconut, Mother's Day Gift, 6.1 oz<br>
					<center>Old price 10 SAR </center> 
					<center>New Price 8 SAR </center>
				</p>
			</div>
		</li>			
	</ul>
	</div>

	
   </article>
   
   
<?php include 'footer.php'; ?>